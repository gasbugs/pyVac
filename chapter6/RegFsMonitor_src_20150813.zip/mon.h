
#pragma once


#include <windows.h>
#include <tchar.h>
#include <io.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <mysql.h> // MySQL�� �����ϱ� ���� �� �ʿ��� ��� ����

#define SOCKET int // �̰� ����� �Ѵٰ� �ϴ����


/* DB ���� ����*/
#define HOST "localhost"	// ������ host �ּ�
#define USER "root"			// ����� �̸�
#define PASS "apmsetup"		// �н�����
#define NAME "prfmonitor"	// ������ DB �̸�

#define STATUS_SUCCESS ((NTSTATUS)0x00000000L)

#define FILE_CHANGE_FLAGS FILE_NOTIFY_CHANGE_FILE_NAME |\
					 FILE_NOTIFY_CHANGE_DIR_NAME |\
					 FILE_NOTIFY_CHANGE_ATTRIBUTES |\
					 FILE_NOTIFY_CHANGE_SIZE |\
					 FILE_NOTIFY_CHANGE_CREATION |\
					 FILE_NOTIFY_CHANGE_SECURITY

#define REG_CHANGE_FLAGS REG_NOTIFY_CHANGE_NAME |\
					 REG_NOTIFY_CHANGE_LAST_SET

// MySQL Query �Լ�
MYSQL* initMySQL();
int QueryToMySQL(MYSQL * conn_ptr, LPTSTR query);
int MySQLClose(MYSQL * conn_ptr);

void Output_reg(USHORT Color, LPTSTR format, ...);
void Output_file(USHORT Color, LPTSTR format, ...);
void StartFileMonitor(void);
void StartRegistryMonitor(void);
HANDLE MakeFile(LPTSTR filename);

extern HANDLE  g_hStopEvent;
extern HANDLE  g_hRegWatch[2];

// whitelisted filenames or paths
static LPTSTR g_szAllow[] = {
	_T("WINDOWS\\system32\\config\\"),
	_T("\\ntuser.dat.LOG"),
	_T("UsrClass.dat.LOG"),
	_T("RegFsNotify.txt"),
	_T("_restore"),
	_T("CatRoot2"),
	_T("\\Microsoft\\Cryptography\\RNG"),
	_T("\\Microsoft\\WBEM"),
};

// return true if szFile is in the g_szAllow list
static BOOL IsWhitelisted(LPTSTR szFile)
{
	for(int i=0; i<sizeof(g_szAllow)/sizeof(LPTSTR); i++)
	{
		if (_tcsstr(szFile, g_szAllow[i]) != NULL) 
			return TRUE;
	}
	return FALSE;
}